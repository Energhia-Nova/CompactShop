<?php defined('SYSPATH') or die('No direct script access.');

class Model_Supplier extends ORM {
        
}