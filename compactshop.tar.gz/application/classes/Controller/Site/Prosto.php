<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Site_Prosto extends Controller {
    
    public function action_index()
	 {
	 		echo "Ja Site Route"; exit;	 
    }
}