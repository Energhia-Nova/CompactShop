<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2016-09-15 07:43:14 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 07:43:14 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 07:51:24 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 07:51:24 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 08:21:32 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 08:21:32 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 08:22:00 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 08:22:00 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 08:28:24 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 08:28:24 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 08:29:07 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 08:29:07 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 08:36:33 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 08:36:33 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 08:36:55 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 08:36:55 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 08:37:28 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 08:37:28 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 08:42:41 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 08:42:41 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 08:46:39 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 08:46:39 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 09:20:34 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 09:20:34 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 09:54:59 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 09:54:59 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 09:56:08 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 09:56:08 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 09:59:13 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 09:59:13 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 09:59:59 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 09:59:59 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 10:18:39 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 10:18:39 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 10:20:02 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 10:20:02 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 10:25:22 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 119 ] in file:line
2016-09-15 10:25:22 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 10:31:49 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 121 ] in file:line
2016-09-15 10:31:49 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 10:36:55 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 123 ] in file:line
2016-09-15 10:36:55 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 10:38:26 --- EMERGENCY: ErrorException [ 1 ]: Class 'Object' not found ~ SYSPATH/classes/Kohana/Request/Client.php [ 121 ] in file:line
2016-09-15 10:38:26 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 10:38:53 --- EMERGENCY: ErrorException [ 2 ]: Creating default object from empty value ~ SYSPATH/classes/Kohana/Request/Client.php [ 122 ] in /var/www/html/CompactShop/system/classes/Kohana/Request/Client.php:122
2016-09-15 10:38:53 --- DEBUG: #0 /var/www/html/CompactShop/system/classes/Kohana/Request/Client.php(122): Kohana_Core::error_handler(2, 'Creating defaul...', '/var/www/html/C...', 122, Array)
#1 /var/www/html/CompactShop/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/html/CompactShop/index.php(118): Kohana_Request->execute()
#3 {main} in /var/www/html/CompactShop/system/classes/Kohana/Request/Client.php:122
2016-09-15 10:40:30 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 125 ] in file:line
2016-09-15 10:40:30 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 10:42:59 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 126 ] in file:line
2016-09-15 10:42:59 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 10:43:18 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 126 ] in file:line
2016-09-15 10:43:18 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 10:43:50 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected 'public' (T_PUBLIC), expecting class (T_CLASS) ~ SYSPATH/classes/Kohana/Request/Client.php [ 165 ] in file:line
2016-09-15 10:43:50 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 10:50:52 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 126 ] in file:line
2016-09-15 10:50:52 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 11:02:49 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 126 ] in file:line
2016-09-15 11:02:49 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 11:07:32 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 126 ] in file:line
2016-09-15 11:07:32 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 11:11:41 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected 'public' (T_PUBLIC) ~ APPPATH/classes/Request.php [ 9 ] in file:line
2016-09-15 11:11:41 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 11:12:49 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 126 ] in file:line
2016-09-15 11:12:49 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 11:17:30 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 126 ] in file:line
2016-09-15 11:17:30 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 11:18:23 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 126 ] in file:line
2016-09-15 11:18:23 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 11:20:54 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 129 ] in file:line
2016-09-15 11:20:54 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 11:35:27 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 129 ] in file:line
2016-09-15 11:35:27 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 11:35:39 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 129 ] in file:line
2016-09-15 11:35:39 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 11:39:40 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 129 ] in file:line
2016-09-15 11:39:40 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 11:43:19 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 129 ] in file:line
2016-09-15 11:43:19 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 11:43:29 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 129 ] in file:line
2016-09-15 11:43:29 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 11:47:47 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 129 ] in file:line
2016-09-15 11:47:47 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 11:48:00 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 129 ] in file:line
2016-09-15 11:48:00 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 11:48:41 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 129 ] in file:line
2016-09-15 11:48:41 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 11:53:16 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: requst ~ SYSPATH/classes/Kohana/Request/Client.php [ 117 ] in /var/www/html/CompactShop/system/classes/Kohana/Request/Client.php:117
2016-09-15 11:53:16 --- DEBUG: #0 /var/www/html/CompactShop/system/classes/Kohana/Request/Client.php(117): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/html/C...', 117, Array)
#1 /var/www/html/CompactShop/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/html/CompactShop/index.php(118): Kohana_Request->execute()
#3 {main} in /var/www/html/CompactShop/system/classes/Kohana/Request/Client.php:117
2016-09-15 11:53:29 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 125 ] in file:line
2016-09-15 11:53:29 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 13:46:17 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 125 ] in file:line
2016-09-15 13:46:17 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 13:52:38 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 125 ] in file:line
2016-09-15 13:52:38 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 13:54:37 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function send_headers() on null ~ DOCROOT/index.php [ 121 ] in file:line
2016-09-15 13:54:37 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 13:58:44 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 125 ] in file:line
2016-09-15 13:58:44 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 14:03:54 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 125 ] in file:line
2016-09-15 14:03:54 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 14:34:21 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function send_headers() on null ~ DOCROOT/index.php [ 121 ] in file:line
2016-09-15 14:34:21 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 14:35:28 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function send_headers() on null ~ DOCROOT/index.php [ 121 ] in file:line
2016-09-15 14:35:28 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 14:38:23 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 125 ] in file:line
2016-09-15 14:38:23 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 14:38:37 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 125 ] in file:line
2016-09-15 14:38:37 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 14:41:06 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_Option' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2016-09-15 14:41:06 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 14:44:06 --- EMERGENCY: ErrorException [ 1 ]: Class 'Auth' not found ~ APPPATH/classes/Controller/Signup.php [ 22 ] in file:line
2016-09-15 14:44:06 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 14:48:44 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_Page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2016-09-15 14:48:44 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 14:50:17 --- EMERGENCY: ErrorException [ 2 ]: Attempt to assign property of non-object ~ APPPATH/classes/Controller/Signup.php [ 43 ] in /var/www/html/CompactShop/application/classes/Controller/Signup.php:43
2016-09-15 14:50:17 --- DEBUG: #0 /var/www/html/CompactShop/application/classes/Controller/Signup.php(43): Kohana_Core::error_handler(2, 'Attempt to assi...', '/var/www/html/C...', 43, Array)
#1 /var/www/html/CompactShop/system/classes/Kohana/Controller.php(72): Controller_Signup->before()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/CompactShop/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Signup))
#4 /var/www/html/CompactShop/system/classes/Kohana/Request/Client.php(119): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/CompactShop/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/CompactShop/index.php(120): Kohana_Request->execute()
#7 {main} in /var/www/html/CompactShop/application/classes/Controller/Signup.php:43
2016-09-15 14:54:31 --- EMERGENCY: ErrorException [ 2 ]: Attempt to assign property of non-object ~ APPPATH/classes/Controller/Signup.php [ 44 ] in /var/www/html/CompactShop/application/classes/Controller/Signup.php:44
2016-09-15 14:54:31 --- DEBUG: #0 /var/www/html/CompactShop/application/classes/Controller/Signup.php(44): Kohana_Core::error_handler(2, 'Attempt to assi...', '/var/www/html/C...', 44, Array)
#1 /var/www/html/CompactShop/system/classes/Kohana/Controller.php(72): Controller_Signup->before()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/CompactShop/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Signup))
#4 /var/www/html/CompactShop/system/classes/Kohana/Request/Client.php(119): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/CompactShop/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/CompactShop/index.php(120): Kohana_Request->execute()
#7 {main} in /var/www/html/CompactShop/application/classes/Controller/Signup.php:44
2016-09-15 14:55:36 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 125 ] in file:line
2016-09-15 14:55:36 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 14:58:42 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 125 ] in file:line
2016-09-15 14:58:42 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 14:59:19 --- EMERGENCY: ErrorException [ 2 ]: Attempt to assign property of non-object ~ APPPATH/classes/Controller/Signup.php [ 44 ] in /var/www/html/CompactShop/application/classes/Controller/Signup.php:44
2016-09-15 14:59:19 --- DEBUG: #0 /var/www/html/CompactShop/application/classes/Controller/Signup.php(44): Kohana_Core::error_handler(2, 'Attempt to assi...', '/var/www/html/C...', 44, Array)
#1 /var/www/html/CompactShop/system/classes/Kohana/Controller.php(72): Controller_Signup->before()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/CompactShop/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Signup))
#4 /var/www/html/CompactShop/system/classes/Kohana/Request/Client.php(119): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/CompactShop/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/CompactShop/index.php(120): Kohana_Request->execute()
#7 {main} in /var/www/html/CompactShop/application/classes/Controller/Signup.php:44
2016-09-15 15:01:11 --- EMERGENCY: ErrorException [ 2 ]: Attempt to assign property of non-object ~ APPPATH/classes/Controller/Signup.php [ 44 ] in /var/www/html/CompactShop/application/classes/Controller/Signup.php:44
2016-09-15 15:01:11 --- DEBUG: #0 /var/www/html/CompactShop/application/classes/Controller/Signup.php(44): Kohana_Core::error_handler(2, 'Attempt to assi...', '/var/www/html/C...', 44, Array)
#1 /var/www/html/CompactShop/system/classes/Kohana/Controller.php(72): Controller_Signup->before()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/CompactShop/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Signup))
#4 /var/www/html/CompactShop/system/classes/Kohana/Request/Client.php(119): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/CompactShop/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/CompactShop/index.php(120): Kohana_Request->execute()
#7 {main} in /var/www/html/CompactShop/application/classes/Controller/Signup.php:44
2016-09-15 15:02:17 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 125 ] in file:line
2016-09-15 15:02:17 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 15:03:05 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 125 ] in file:line
2016-09-15 15:03:05 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-15 15:03:19 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 125 ] in file:line
2016-09-15 15:03:19 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line