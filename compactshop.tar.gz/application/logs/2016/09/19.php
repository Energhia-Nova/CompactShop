<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2016-09-19 08:47:50 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function send_headers() on null ~ DOCROOT/index.php [ 118 ] in file:line
2016-09-19 08:47:50 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-19 08:49:07 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function send_headers() on null ~ DOCROOT/index.php [ 118 ] in file:line
2016-09-19 08:49:07 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-19 09:07:29 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function send_headers() on null ~ DOCROOT/index.php [ 118 ] in file:line
2016-09-19 09:07:29 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-19 09:16:08 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function send_headers() on null ~ DOCROOT/index.php [ 118 ] in file:line
2016-09-19 09:16:08 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-19 09:16:12 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 125 ] in file:line
2016-09-19 09:16:12 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-19 09:18:21 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function headers() on null ~ SYSPATH/classes/Kohana/Request/Client.php [ 125 ] in file:line
2016-09-19 09:18:21 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-19 09:18:27 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function send_headers() on null ~ DOCROOT/index.php [ 118 ] in file:line
2016-09-19 09:18:27 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-09-19 09:24:20 --- EMERGENCY: ErrorException [ 1 ]: Call to a member function send_headers() on null ~ DOCROOT/index.php [ 118 ] in file:line
2016-09-19 09:24:20 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line