<div id="form">
	<form action="" method="post">
		<table style="margin-left:0">
			<tr>
				<td><?=__('Enter the code')?></td>
			</tr>
			<tr>
				<td><input type="text" value="" name="code" /></td>
			</tr>
			<tr>
				<td><input type="submit" value="<?=__('Confirm')?>" /></td>
			</tr>
		</table>
	</form>
</div>