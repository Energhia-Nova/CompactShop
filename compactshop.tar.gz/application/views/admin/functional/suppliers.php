<ul class="nav nav-tabs nav-stacked">
	<li><a href="/admin/suppliers"><?=__('Suppliers')?></a></li>
    <li><a href="/admin/suppliers/new-supplier"><?=__('add Supplier')?></a></li>    
</ul>