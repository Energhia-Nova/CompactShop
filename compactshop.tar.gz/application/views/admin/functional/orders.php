<ul class="nav nav-tabs nav-stacked">
	<li><a href="/admin/orders"><?=__('Orders list')?></a></li>
    <li><a href="/admin/orders/new-order"><?=__('add Order')?></a></li>
</ul>