<ul class="nav nav-tabs nav-stacked">
	<li><a href="/admin/categories"><?=__('Categories list')?></a></li>
    <li><a href="/admin/categories/new-category"><?=__('New Category')?></a></li>
</ul>