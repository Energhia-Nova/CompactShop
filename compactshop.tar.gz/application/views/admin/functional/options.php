<ul class="nav nav-tabs nav-stacked">
    <li><a href="/admin/options"><?=__('Options List')?></a></li>
	<li><a href="/admin/options/new-option"><?=__('Option Create')?></a></li>
</ul>