<ul class="nav nav-tabs nav-stacked">
	<li><a href="/admin/users"><?=__('Users list')?></a></li>
    <li><a href="/admin/users/create-user"><?=__('Create user')?></a></li>
</ul>