<ul class="nav nav-tabs nav-stacked">
	<li><a href="/admin/brands"><?=__('Brands list')?></a></li>
    <li><a href="/admin/brands/new-brand"><?=__('add Brand')?></a></li>
</ul>