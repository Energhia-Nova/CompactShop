<ul class="nav nav-tabs nav-stacked">
    <li><a href="/admin/update"><?=__('Update')?></a></li>    
    <li><a href="/admin/modules">Module</a></li>
    <li><a href="/admin/language"><?=__('Language')?></a></li>
	<li><a href="/admin/email">Email</a></li>
    <li><a href="/admin/options"><?=__('Options')?></a></li>
    <li><a href="/admin/design">Design</a></li>
</ul>