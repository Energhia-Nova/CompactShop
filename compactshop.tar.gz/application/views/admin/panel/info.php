<div class="navbar">
  <div class="navbar-inner">
    <a class="brand" href="#"><?=__('Information')?></a>
  </div>
</div>
<table class="tproducts table table-bordered table-striped table-hover">
<tr><td><?=__('Products in Store')?></td><td><?=$all_products?></td></tr>
<tr><td><?=__('Sales per a day')?></td><td>20</td></tr>
<tr><td><?=__('Purchases in a cart')?></td><td>30</td></tr>
<tr><td><?=__('Registered users')?></td><td>100</td></tr>
<tr><td><?=__('Visitors today')?></td><td>20</td></tr>
</table>