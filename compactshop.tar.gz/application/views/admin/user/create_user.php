<form action="" method="post" id="product">
<div class="navbar">
  <div class="navbar-inner">
    <a class="brand" href="#"><?=__('User')?></a>
  </div>
</div>
<table class="tnewuser" border="0">
<tr>
	<td>&nbsp; </td><td><input type="text" value="" name="login" /> Login</td>
</tr>
<tr>
	<td>&nbsp; </td><td><input type="text" value="" name="email" /> Email</td>
</tr>
<tr>
	<td>&nbsp;</td><td><input type="submit" value="<?=__('add')?>" name="save" class="btn" /></td>
</tr>
</table>