<div class="navbar">
  <div class="navbar-inner">
    <a class="brand" href="#"><?=__('Categories')?></a>
  </div>
</div>
<div id="menu-container">
<div class="categories"><?=$categories?></div>
</div>