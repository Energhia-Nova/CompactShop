<?php defined('SYSPATH') OR die('No direct script access.');

return array(

	'Spanish' => 'Español',
	'Hello, world!' => '¡Hola, mundo!',

);
