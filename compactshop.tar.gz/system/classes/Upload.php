<?php defined('SYSPATH') OR die('No direct script access.');

class Upload extends Kohana_Upload {}
