<?php
// See the Kohana_CoreTest tests for Kohana::message
return array(
	'top_only'      => 'top only message',
	'cfs_replaced'  => 'overriding cfs_replaced message',
);
