Discuss security of cookies, like changing the encryption key in the config.

Not sure why I'm linking to this: <http://kohanaframework.org/guide/security.cookies>