<?php defined('SYSPATH') OR die('No direct script access.');

class Database_Result_Cached extends Kohana_Database_Result_Cached {}
