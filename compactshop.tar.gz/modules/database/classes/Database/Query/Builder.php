<?php defined('SYSPATH') OR die('No direct script access.');

abstract class Database_Query_Builder extends Kohana_Database_Query_Builder {}
