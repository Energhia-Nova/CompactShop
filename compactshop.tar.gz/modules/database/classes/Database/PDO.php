<?php defined('SYSPATH') OR die('No direct script access.');

class Database_PDO extends Kohana_Database_PDO {}
