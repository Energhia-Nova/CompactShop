<?php defined('SYSPATH') or die('No direct script access.');

class Pagination extends Kohana_Pagination {}